# TrapsCore — Traps Craft SMP

A modular Paper plugin for the Traps Craft survival server.

## Target

- Paper API: `1.21.11-R0.1-SNAPSHOT`
- Java: 21
- Build: Maven
- Storage: SQLite (single serialized database executor)
- Java/Bedrock: standard Bukkit inventories and commands; Bedrock access is provided separately by GeyserMC + Floodgate. ViaVersion is a separate optional Java protocol bridge.

The plugin targets Paper 1.21.11. It does **not** promise every historical or future client/server version. Test the exact Paper, Geyser, Floodgate and ViaVersion versions you intend to run.

## Implemented source modules

### Existing core retained

- `/spawn`, `/setspawn`
- `/balance` (`/bal`), `/pay`, `/eco`
- Existing player balances are migrated from the original `balances` table into integer-cent wallets on startup.

### `/shop`

- Category GUI and item GUI built with standard chest inventories.
- Restricted hard-coded allowlist for survival supplies, storage utility and non-explosive redstone/mechanical components.
- 27 initial configured entries in `src/main/resources/shop.yml`.
- No armor, swords, bows, crossbows, End Crystals, TNT, Respawn Anchors or general building-block catalogue.
- Each item's enabled flag, price, amount and display name can be changed in `shop.yml`; `/shop reload` reloads it without recompiling.
- Purchases debit the shared wallet and create a persistent item-delivery record in the same SQLite transaction.

### `/ah` — player auction house

- `/ah` opens a paginated listing GUI.
- `/ah sell <price> [amount]` lists the item held in the main hand.
- `/ah cancel <id>` cancels one of the seller's active listings; the short ID shown in the GUI is accepted when unique.
- The auction accepts blocks, edible supplies and selected utility items only; weapons, armor, projectiles, explosives and container items that could hide restricted gear are rejected from new listings and hidden from the GUI.
- Purchase confirmation GUI; the buyer is charged, seller credited, listing marked sold and delivery journaled in one SQLite transaction.
- Listings expire after `auction.expire-days` (default 7); cancellation and expiry enqueue a durable return to the seller.
- Listing escrow uses a prepared state and a temporary item marker so normal restarts can reconcile an interrupted listing attempt.

### Delivery and transaction safety

- Wallet values are stored as integer cents, not floating-point amounts.
- Shop and auction operations use one serialized SQLite executor and SQL transactions.
- Auction purchase is a compare-and-set state transition (`ACTIVE` → `SOLD`) in the same transaction as both wallet changes and item delivery creation.
- Item deliveries are journaled as `PENDING`, tagged while being placed in inventory, then marked delivered. Tagged items are locked from ordinary inventory movement/use until the database confirms completion; pending deliveries are retried on join.
- Cancelled/expired auction items are kept in persistent return deliveries until the seller receives them.

## Configuration

- `config.yml`: currency symbol, starting balance, spawn and auction expiry.
- `shop.yml`: categories, enabled items, prices, quantities and display names.
- Only materials in the Java allowlist are accepted even if someone adds other entries to `shop.yml`.

## Build

Requires JDK 21 and Maven 3.9+:

```bash
mvn clean verify
```

The shaded plugin JAR should be created at `target/TrapsCore.jar`. Install it into the Paper server's `plugins` directory and restart.

A GitHub Actions build workflow is included in `.github/workflows/build.yml`.

## Verification status for this source revision

- `MoneyManualCheck`: passed locally (13 checks) using JDK 21; `MoneyTest` is also wired for Maven Surefire/JUnit 5.
- Full source syntax check: passed against temporary minimal Bukkit API stubs. This catches Java syntax/type-flow issues but is **not** a substitute for compiling against the real Paper API.
- Shop YAML: parsed and checked; all 27 entries are in the intended allowlist, with positive prices and valid quantities; no armor, weapons, bows or explosive materials.
- SQLite SQL smoke test: schema and the shop purchase, auction purchase, and auction-return transaction paths passed using Python's SQLite engine.
- A real Maven/Paper build and live server test were **not run** in this environment because Maven is not installed and external dependency downloads are unavailable. No JAR is included or claimed as built.

## Important operational note

The database journal greatly reduces item-loss and duplication risk and recovers interrupted delivery/listing states on player join. No plugin can make Bukkit player-data saves and a separate SQLite file one atomic filesystem transaction during a sudden machine/power failure. Back up both the Paper world/player data and `plugins/TrapsCore/data.db` together, and test restart/crash recovery on a staging server before production use.
