package com.trapscraft.core;

import com.trapscraft.core.auction.AuctionCommand;
import com.trapscraft.core.auction.AuctionService;
import com.trapscraft.core.command.BalanceCommand;
import com.trapscraft.core.command.EcoCommand;
import com.trapscraft.core.command.PayCommand;
import com.trapscraft.core.command.SetSpawnCommand;
import com.trapscraft.core.command.SpawnCommand;
import com.trapscraft.core.delivery.DeliveryService;
import com.trapscraft.core.economy.EconomyService;
import com.trapscraft.core.menu.MenuListener;
import com.trapscraft.core.shop.ShopCommand;
import com.trapscraft.core.shop.ShopService;
import com.trapscraft.core.storage.SQLiteStorage;
import com.trapscraft.core.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class TrapsCore extends JavaPlugin {
    private SQLiteStorage storage;
    private EconomyService economy;
    private Messages messages;
    private DeliveryService deliveries;
    private ShopService shop;
    private AuctionService auctions;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("shop.yml", false);
        this.messages = new Messages(this);

        try {
            this.storage = new SQLiteStorage(this);
            this.storage.initialize(this);
        } catch (Exception exception) {
            getLogger().severe("Could not initialize SQLite storage: " + exception.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.economy = new EconomyService(storage);
        this.deliveries = new DeliveryService(this, storage);
        this.shop = new ShopService(this, storage, deliveries);
        this.auctions = new AuctionService(this, storage, deliveries);

        register("spawn", new SpawnCommand(this));
        register("setspawn", new SetSpawnCommand(this));
        register("balance", new BalanceCommand(this));
        register("pay", new PayCommand(this));
        register("eco", new EcoCommand(this));
        register("shop", new ShopCommand(this, shop));
        register("ah", new AuctionCommand(this, auctions));

        Bukkit.getPluginManager().registerEvents(new MenuListener(shop, auctions, deliveries), this);
        for (org.bukkit.entity.Player player : Bukkit.getOnlinePlayers()) {
            auctions.recoverPrepared(player);
            deliveries.handleJoin(player);
        }
        Bukkit.getScheduler().runTaskTimer(this, auctions::scheduledMaintenance, 20L, 1200L);
        auctions.scheduledMaintenance();
        getLogger().info("TrapsCore enabled. Economy, restricted shop and auction house are loaded.");
    }

    private void register(String name, org.bukkit.command.CommandExecutor executor) {
        PluginCommand command = Objects.requireNonNull(getCommand(name), "Missing command in plugin.yml: " + name);
        command.setExecutor(executor);
    }

    @Override
    public void onDisable() {
        if (storage != null) storage.close();
        getLogger().info("TrapsCore disabled.");
    }

    public EconomyService economy() { return economy; }
    public Messages messages() { return messages; }
}
