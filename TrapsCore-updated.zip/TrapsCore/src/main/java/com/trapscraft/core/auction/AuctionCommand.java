package com.trapscraft.core.auction;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.util.Money;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class AuctionCommand implements CommandExecutor {
    private final TrapsCore plugin;
    private final AuctionService auctions;

    public AuctionCommand(TrapsCore plugin, AuctionService auctions) {
        this.plugin = plugin;
        this.auctions = auctions;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "players-only");
            return true;
        }
        if (args.length == 0) {
            auctions.open(player, 0);
            return true;
        }
        if (args[0].equalsIgnoreCase("sell")) {
            if (args.length < 2 || args.length > 3) {
                player.sendMessage(plugin.messages().color("&cاستخدم: /ah sell <price> [amount]"));
                return true;
            }
            try {
                long price = Money.parseCents(args[1]);
                int amount = args.length == 3 ? Integer.parseInt(args[2]) : player.getInventory().getItemInMainHand().getAmount();
                if (amount < 1 || amount > 64) throw new IllegalArgumentException("invalid amount");
                auctions.createListing(player, price, amount);
            } catch (IllegalArgumentException exception) {
                player.sendMessage(plugin.messages().color("&cالسعر أو الكمية غير صحيحة"));
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("cancel")) {
            if (args.length != 2) {
                player.sendMessage(plugin.messages().color("&cاستخدم: /ah cancel <id>"));
                return true;
            }
            auctions.cancelListing(player, args[1]);
            return true;
        }
        player.sendMessage(plugin.messages().color("&e/ah &7- فتح المزاد"));
        player.sendMessage(plugin.messages().color("&e/ah sell <price> [amount] &7- عرض الغرض"));
        player.sendMessage(plugin.messages().color("&e/ah cancel <id> &7- إلغاء إعلانك"));
        return true;
    }
}
