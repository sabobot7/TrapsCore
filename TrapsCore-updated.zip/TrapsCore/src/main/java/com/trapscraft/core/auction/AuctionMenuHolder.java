package com.trapscraft.core.auction;

import com.trapscraft.core.storage.SQLiteStorage;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

public final class AuctionMenuHolder implements InventoryHolder {
    public enum Type { LIST, CONFIRM }
    private final Type type;
    private final int page;
    private final Map<Integer, SQLiteStorage.AuctionListing> listings = new HashMap<>();
    private SQLiteStorage.AuctionListing selected;
    private String deliveryId;
    private Inventory inventory;

    public AuctionMenuHolder(Type type, int page) { this.type = type; this.page = page; }
    public Type type() { return type; }
    public int page() { return page; }
    public Map<Integer, SQLiteStorage.AuctionListing> listings() { return listings; }
    public SQLiteStorage.AuctionListing selected() { return selected; }
    public void selected(SQLiteStorage.AuctionListing selected) { this.selected = selected; }
    public String deliveryId() { return deliveryId; }
    public void deliveryId(String deliveryId) { this.deliveryId = deliveryId; }
    public void inventory(Inventory inventory) { this.inventory = inventory; }
    @Override public Inventory getInventory() { return inventory; }
}
