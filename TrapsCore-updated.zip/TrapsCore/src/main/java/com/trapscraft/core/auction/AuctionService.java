package com.trapscraft.core.auction;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.delivery.DeliveryService;
import com.trapscraft.core.storage.SQLiteStorage;
import com.trapscraft.core.util.Money;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AuctionService {
    private final TrapsCore plugin;
    private final SQLiteStorage storage;
    private final DeliveryService deliveries;
    private final NamespacedKey draftKey;
    private final Set<UUID> pendingSellers = ConcurrentHashMap.newKeySet();
    private final Set<String> buying = ConcurrentHashMap.newKeySet();

    public AuctionService(TrapsCore plugin, SQLiteStorage storage, DeliveryService deliveries) {
        this.plugin = plugin;
        this.storage = storage;
        this.deliveries = deliveries;
        this.draftKey = new NamespacedKey(plugin, "auction_draft");
    }

    public void open(Player player, int page) {
        storage.expireAuctions().thenCompose(ignored -> storage.queueAuctionReturns())
                .thenCompose(ignored -> storage.activeAuctions(page, 45))
                .whenComplete((listings, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) return;
                    deliveries.process(player);
                    if (error != null) {
                        plugin.messages().send(player, "database-error");
                        plugin.getLogger().warning("Could not open auction house: " + error.getMessage());
                        return;
                    }
                    openList(player, page, listings);
                }));
    }

    private void openList(Player player, int page, List<SQLiteStorage.AuctionListing> listings) {
        AuctionMenuHolder holder = new AuctionMenuHolder(AuctionMenuHolder.Type.LIST, page);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&3Traps Craft &8| &bAuction House"));
        int slot = 0;
        for (SQLiteStorage.AuctionListing listing : listings) {
            if (slot >= 45) break;
            Material listedMaterial = Material.matchMaterial(listing.material());
            if (listedMaterial == null || !isAuctionMaterialAllowed(listedMaterial)) continue;
            try {
                ItemStack display = ItemStack.deserializeBytes(listing.itemBytes());
                ItemMeta meta = display.getItemMeta();
                List<String> lore = new ArrayList<>();
                lore.add(color("&7البائع: &f" + listing.sellerName()));
                lore.add(color("&7السعر: &a" + currency() + Money.format(listing.priceCents())));
                lore.add(color("&7الكمية: &f" + listing.amount()));
                lore.add(color("&8ID: " + listing.id().substring(0, 8)));
                lore.add(color("&eاضغط للشراء"));
                meta.setLore(lore);
                display.setItemMeta(meta);
                inventory.setItem(slot, display);
                holder.listings().put(slot, listing);
                slot++;
            } catch (Exception exception) {
                plugin.getLogger().warning("Skipped invalid auction item " + listing.id() + ": " + exception.getMessage());
            }
        }
        setButton(inventory, 45, Material.ARROW, "&cالسابق");
        setButton(inventory, 49, Material.CLOCK, "&eتحديث");
        setButton(inventory, 53, Material.ARROW, "&aالتالي");
        holder.inventory(inventory);
        player.openInventory(inventory);
    }

    private void openConfirm(Player player, SQLiteStorage.AuctionListing listing) {
        AuctionMenuHolder holder = new AuctionMenuHolder(AuctionMenuHolder.Type.CONFIRM, 0);
        holder.selected(listing);
        holder.deliveryId(UUID.randomUUID().toString());
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&3تأكيد عملية الشراء"));
        try {
            ItemStack item = ItemStack.deserializeBytes(listing.itemBytes());
            ItemMeta meta = item.getItemMeta();
            meta.setLore(List.of(color("&7البائع: &f" + listing.sellerName()),
                    color("&7السعر: &a" + currency() + Money.format(listing.priceCents()))));
            item.setItemMeta(meta);
            inventory.setItem(13, item);
        } catch (Exception ignored) { }
        setButton(inventory, 11, Material.LIME_CONCRETE, "&aتأكيد الشراء");
        setButton(inventory, 15, Material.RED_CONCRETE, "&cإلغاء");
        holder.inventory(inventory);
        player.openInventory(inventory);
    }

    public void handleClick(Player player, AuctionMenuHolder holder, int slot) {
        if (holder.type() == AuctionMenuHolder.Type.LIST) {
            if (slot == 45) { open(player, Math.max(0, holder.page() - 1)); return; }
            if (slot == 49) { open(player, holder.page()); return; }
            if (slot == 53) { open(player, holder.page() + 1); return; }
            SQLiteStorage.AuctionListing listing = holder.listings().get(slot);
            if (listing != null) openConfirm(player, listing);
            return;
        }
        if (slot == 15) { open(player, 0); return; }
        if (slot != 11 || holder.selected() == null) return;
        SQLiteStorage.AuctionListing listing = holder.selected();
        String lock = player.getUniqueId() + ":" + listing.id();
        if (!buying.add(lock)) return;
        storage.buyAuction(player.getUniqueId(), listing.id(), holder.deliveryId()).whenComplete((result, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    buying.remove(lock);
                    if (!player.isOnline()) return;
                    if (error != null) {
                        plugin.getLogger().warning("Auction purchase failed: " + error.getMessage());
                        plugin.messages().send(player, "database-error");
                        return;
                    }
                    switch (result.status()) {
                        case SUCCESS -> {
                            player.closeInventory();
                            player.sendMessage(color("&aتم الشراء، جاري تسليم الغرض"));
                            deliveries.process(player);
                            Player seller = Bukkit.getPlayer(listing.seller());
                            if (seller != null) seller.sendMessage(color("&aتم بيع إعلانك مقابل " + currency() + Money.format(result.priceCents())));
                        }
                        case INSUFFICIENT_FUNDS -> plugin.messages().send(player, "insufficient-funds");
                        case OWN_LISTING -> player.sendMessage(color("&cما تكدر تشتري إعلانك"));
                        case EXPIRED, UNAVAILABLE, NOT_FOUND -> {
                            player.sendMessage(color("&cهذا الإعلان لم يعد متاحاً"));
                            open(player, 0);
                        }
                    }
                }));
    }

    public void createListing(Player player, long priceCents, int amount) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR || !isAuctionMaterialAllowed(hand.getType())
                || amount < 1 || amount > hand.getAmount()) {
            player.sendMessage(color("&cهذا الغرض غير مسموح بالمزاد أو الكمية غير صحيحة"));
            return;
        }
        if (!pendingSellers.add(player.getUniqueId())) {
            player.sendMessage(color("&cانتظر اكتمال عملية الإعلان السابقة"));
            return;
        }
        String id = UUID.randomUUID().toString();
        ItemStack escrow = hand.clone();
        escrow.setAmount(amount);
        ItemStack marked = hand.clone();
        var markedMeta = marked.getItemMeta();
        markedMeta.getPersistentDataContainer().set(draftKey, PersistentDataType.STRING, id);
        marked.setItemMeta(markedMeta);
        player.getInventory().setItemInMainHand(marked);
        long days = Math.max(1, plugin.getConfig().getLong("auction.expire-days", 7));
        long expiresAt = System.currentTimeMillis() + days * 24L * 60L * 60L * 1000L;
        storage.prepareAuction(id, player.getUniqueId(), player.getName(), escrow.serializeAsBytes(),
                escrow.getType().name(), amount, priceCents, expiresAt).whenComplete((prepared, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null || !Boolean.TRUE.equals(prepared)) {
                        pendingSellers.remove(player.getUniqueId());
                        plugin.getLogger().warning("Could not confirm auction escrow preparation: " + (error == null ? "unknown error" : error.getMessage()));
                        if (player.isOnline()) {
                            plugin.messages().send(player, "database-error");
                            recoverPrepared(player); // preserve the marker until SQLite determines whether the draft exists
                            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                                if (player.isOnline()) recoverPrepared(player);
                            }, 100L);
                        }
                        return;
                    }
                    if (!player.isOnline()) {
                        pendingSellers.remove(player.getUniqueId());
                        return;
                    }
                    if (!removeMarkedAmount(player, id, amount)) {
                        storage.cancelAuctionDraft(id);
                        pendingSellers.remove(player.getUniqueId());
                        player.sendMessage(color("&cتعذر تأمين الغرض، لم يتم إنشاء الإعلان"));
                        return;
                    }
                    pendingSellers.remove(player.getUniqueId());
                    storage.activateAuction(id).whenComplete((activated, activationError) ->
                            Bukkit.getScheduler().runTask(plugin, () -> {
                                if (activationError != null || !Boolean.TRUE.equals(activated)) {
                                    plugin.getLogger().warning("Auction activation deferred for " + id + ": " + (activationError == null ? "not activated" : activationError.getMessage()));
                                    if (player.isOnline()) {
                                        player.sendMessage(color("&eتم حفظ الغرض بأمان، وسيكتمل الإعلان بعد استعادة قاعدة البيانات"));
                                        recoverPrepared(player);
                                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                                            if (player.isOnline()) recoverPrepared(player);
                                        }, 100L);
                                    }
                                } else if (player.isOnline()) {
                                    player.sendMessage(color("&aتم نشر إعلانك بنجاح &7(ID: " + id.substring(0, 8) + ")"));
                                }
                            }));
                }));
    }

    public void cancelListing(Player player, String prefix) {
        if (prefix == null || !prefix.matches("(?i)[a-f0-9-]{4,36}")) {
            player.sendMessage(color("&cاستخدم: /ah cancel <id>"));
            return;
        }
        storage.cancelAuction(player.getUniqueId(), prefix.toLowerCase()).whenComplete((result, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        plugin.messages().send(player, "database-error");
                        return;
                    }
                    switch (result) {
                        case SUCCESS -> {
                            player.sendMessage(color("&aتم إلغاء الإعلان، وسيتم إرجاع الغرض"));
                            queueReturnsAndDeliver(player);
                        }
                        case AMBIGUOUS -> player.sendMessage(color("&eالمعرّف غير كافي، اكتب أحرف أكثر"));
                        case NOT_FOUND -> player.sendMessage(color("&cما لكيت إعلان فعال بهذا المعرّف"));
                    }
                }));
    }

    public void queueReturnsAndDeliver(Player player) {
        storage.expireAuctions().thenCompose(ignored -> storage.queueAuctionReturns())
                .whenComplete((count, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) plugin.getLogger().warning("Could not queue auction returns: " + error.getMessage());
                    if (player.isOnline()) deliveries.process(player);
                }));
    }

    public void scheduledMaintenance() {
        storage.expireAuctions().thenCompose(ignored -> storage.queueAuctionReturns())
                .whenComplete((count, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        plugin.getLogger().warning("Auction expiry maintenance failed: " + error.getMessage());
                        return;
                    }
                    for (Player online : Bukkit.getOnlinePlayers()) deliveries.process(online);
                }));
    }

    public void recoverPrepared(Player player) {
        pendingSellers.remove(player.getUniqueId());
        storage.preparedAuctions(player.getUniqueId()).whenComplete((ids, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null || ids == null || !player.isOnline()) return;
                    clearOrphanDraftMarkers(player, ids);
                    recoverNext(player, ids, 0);
                }));
    }

    private void recoverNext(Player player, List<String> ids, int index) {
        if (!player.isOnline() || index >= ids.size()) return;
        String id = ids.get(index);
        if (hasDraftMarker(player, id)) {
            clearDraftMarker(player, id);
            storage.cancelAuctionDraft(id).whenComplete((ignored, error) ->
                    Bukkit.getScheduler().runTask(plugin, () -> recoverNext(player, ids, index + 1)));
        } else {
            storage.activateAuction(id).whenComplete((activated, error) ->
                    Bukkit.getScheduler().runTask(plugin, () -> recoverNext(player, ids, index + 1)));
        }
    }

    private boolean isAuctionMaterialAllowed(Material material) {
        String name = material.name();
        if (name.endsWith("_SWORD") || name.endsWith("_AXE") || name.endsWith("_ARROW")
                || name.contains("TNT") || name.endsWith("_BED")) return false;
        if (Set.of("BOW", "CROSSBOW", "TRIDENT", "MACE", "ARROW", "END_CRYSTAL",
                "RESPAWN_ANCHOR", "FLINT_AND_STEEL", "FIRE_CHARGE", "LAVA_BUCKET",
                "GUNPOWDER", "FIREWORK_ROCKET", "WIND_CHARGE", "BREEZE_ROD",
                "OBSIDIAN", "CRYING_OBSIDIAN", "GLOWSTONE", "SHULKER_BOX", "BUNDLE",
                "WITHER_SKELETON_SKULL", "WITHER_SKELETON_WALL_SKULL",
                "SPLASH_POTION", "LINGERING_POTION", "POTION").contains(name)) return false;
        return material.isBlock() || material.isEdible()
                || Set.of("TOTEM_OF_UNDYING", "ENDER_PEARL", "WATER_BUCKET", "COMPASS",
                "CLOCK", "MAP", "RECOVERY_COMPASS", "NAME_TAG", "LEAD", "SADDLE").contains(name);
    }

    public boolean isPendingSeller(UUID uuid) { return pendingSellers.contains(uuid); }
    public boolean isDraftItem(ItemStack item) { return draftId(item) != null; }
    public boolean hasDraftItems(Player player) {
        for (ItemStack item : player.getInventory().getContents()) if (isDraftItem(item)) return true;
        return isDraftItem(player.getInventory().getItemInOffHand());
    }

    public void handleDeath(Player player, List<ItemStack> drops) {
        List<String> ids = new ArrayList<>();
        for (ItemStack item : drops) {
            String id = draftId(item);
            if (id != null) {
                ids.add(id);
                clearMarker(item);
            }
        }
        for (String id : ids) storage.cancelAuctionDraft(id);
        pendingSellers.remove(player.getUniqueId());
    }

    private boolean removeMarkedAmount(Player player, String id, int amount) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int slot = 0; slot < contents.length; slot++) {
            ItemStack item = contents[slot];
            if (!id.equals(draftId(item))) continue;
            if (item.getAmount() < amount) return false;
            if (item.getAmount() == amount) player.getInventory().setItem(slot, null);
            else {
                item.setAmount(item.getAmount() - amount);
                clearMarker(item);
                player.getInventory().setItem(slot, item);
            }
            return true;
        }
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (id.equals(draftId(offhand)) && offhand.getAmount() >= amount) {
            if (offhand.getAmount() == amount) player.getInventory().setItemInOffHand(null);
            else {
                offhand.setAmount(offhand.getAmount() - amount);
                clearMarker(offhand);
                player.getInventory().setItemInOffHand(offhand);
            }
            return true;
        }
        return false;
    }


    private void clearOrphanDraftMarkers(Player player, List<String> preparedIds) {
        Set<String> known = Set.copyOf(preparedIds);
        ItemStack[] contents = player.getInventory().getContents();
        for (int slot = 0; slot < contents.length; slot++) {
            String id = draftId(contents[slot]);
            if (id != null && !known.contains(id)) {
                clearMarker(contents[slot]);
                player.getInventory().setItem(slot, contents[slot]);
            }
        }
        ItemStack offhand = player.getInventory().getItemInOffHand();
        String offhandId = draftId(offhand);
        if (offhandId != null && !known.contains(offhandId)) {
            clearMarker(offhand);
            player.getInventory().setItemInOffHand(offhand);
        }
    }

    private boolean hasDraftMarker(Player player, String id) {
        for (ItemStack item : player.getInventory().getContents()) if (id.equals(draftId(item))) return true;
        return id.equals(draftId(player.getInventory().getItemInOffHand()));
    }

    private void clearDraftMarker(Player player, String id) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int slot = 0; slot < contents.length; slot++) {
            if (id.equals(draftId(contents[slot]))) {
                clearMarker(contents[slot]);
                player.getInventory().setItem(slot, contents[slot]);
            }
        }
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (id.equals(draftId(offhand))) {
            clearMarker(offhand);
            player.getInventory().setItemInOffHand(offhand);
        }
    }

    private String draftId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(draftKey, PersistentDataType.STRING);
    }

    private void clearMarker(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return;
        var meta = item.getItemMeta();
        meta.getPersistentDataContainer().remove(draftKey);
        item.setItemMeta(meta);
    }

    private void setButton(Inventory inventory, int slot, Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color(name));
        item.setItemMeta(meta);
        inventory.setItem(slot, item);
    }

    private String currency() { return plugin.getConfig().getString("currency.symbol", "$" ); }
    private String color(String text) { return ChatColor.translateAlternateColorCodes('&', text); }
}
