package com.trapscraft.core.command;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.trapscraft.core.util.Money;

public final class BalanceCommand implements CommandExecutor {
    private final TrapsCore plugin;
    private final Messages messages;

    public BalanceCommand(TrapsCore plugin) {
        this.plugin = plugin;
        this.messages = plugin.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        boolean other = args.length > 0;
        if (other) {
            if (!sender.hasPermission("trapscore.balance.others")) {
                messages.send(sender, "no-permission");
                return true;
            }
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                messages.send(sender, "player-not-found");
                return true;
            }
        } else if (sender instanceof Player player) {
            target = player;
        } else {
            messages.send(sender, "players-only");
            return true;
        }

        Player finalTarget = target;
        plugin.economy().getBalanceCents(target.getUniqueId()).whenComplete((balanceCents, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        messages.send(sender, "database-error");
                        plugin.getLogger().warning("Balance lookup failed: " + error.getMessage());
                        return;
                    }
                    String symbol = plugin.getConfig().getString("currency.symbol", "$" );
                    String amount = Money.format(balanceCents);
                    if (other) {
                        messages.send(sender, "balance-other", "%player%", finalTarget.getName(), "%symbol%", symbol, "%amount%", amount);
                    } else {
                        messages.send(sender, "balance", "%symbol%", symbol, "%amount%", amount);
                    }
                }));
        return true;
    }
}
