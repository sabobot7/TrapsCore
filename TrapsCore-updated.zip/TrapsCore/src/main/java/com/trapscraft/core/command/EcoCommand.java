package com.trapscraft.core.command;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.util.Messages;
import com.trapscraft.core.util.Money;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Locale;

public final class EcoCommand implements CommandExecutor {
    private final TrapsCore plugin;
    private final Messages messages;

    public EcoCommand(TrapsCore plugin) {
        this.plugin = plugin;
        this.messages = plugin.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("trapscore.admin.economy")) {
            messages.send(sender, "no-permission");
            return true;
        }
        if (args.length != 3) {
            messages.send(sender, "eco-usage");
            return true;
        }
        String operation = args[0].toLowerCase(Locale.ROOT);
        if (!operation.equals("give") && !operation.equals("take") && !operation.equals("set")) {
            messages.send(sender, "eco-usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            messages.send(sender, "player-not-found");
            return true;
        }
        long amountCents;
        try {
            amountCents = Money.parseNonNegativeCents(args[2]);
        } catch (IllegalArgumentException exception) {
            messages.send(sender, "invalid-number");
            return true;
        }
        if (operation.equals("give") && amountCents == 0) {
            messages.send(sender, "invalid-number");
            return true;
        }

        Player finalTarget = target;
        plugin.economy().modifyCents(target.getUniqueId(), amountCents, operation).whenComplete((balance, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        messages.send(sender, "database-error");
                        plugin.getLogger().warning("Admin economy operation failed: " + error.getMessage());
                        return;
                    }
                    if (!balance.success()) {
                        messages.send(sender, "insufficient-funds");
                        return;
                    }
                    String symbol = plugin.getConfig().getString("currency.symbol", "$" );
                    messages.send(sender, "eco-success", "%player%", finalTarget.getName(), "%symbol%", symbol,
                            "%amount%", Money.format(balance.balanceCents()));
                }));
        return true;
    }
}
