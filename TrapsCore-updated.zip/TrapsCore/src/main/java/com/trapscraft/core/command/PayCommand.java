package com.trapscraft.core.command;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.storage.SQLiteStorage;
import com.trapscraft.core.util.Messages;
import com.trapscraft.core.util.Money;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public final class PayCommand implements CommandExecutor {
    private final TrapsCore plugin;
    private final Messages messages;

    public PayCommand(TrapsCore plugin) {
        this.plugin = plugin;
        this.messages = plugin.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player payer)) {
            messages.send(sender, "players-only");
            return true;
        }
        if (args.length != 2) {
            messages.send(payer, "pay-usage");
            return true;
        }
        Player recipient = Bukkit.getPlayerExact(args[0]);
        if (recipient == null) {
            messages.send(payer, "player-not-found");
            return true;
        }
        if (recipient.getUniqueId().equals(payer.getUniqueId())) {
            messages.send(payer, "pay-self");
            return true;
        }

        long amountCents;
        try {
            amountCents = Money.parseCents(args[1]);
        } catch (IllegalArgumentException exception) {
            messages.send(payer, "invalid-number");
            return true;
        }

        Player finalRecipient = recipient;
        plugin.economy().payCents(payer.getUniqueId(), recipient.getUniqueId(), amountCents).whenComplete((result, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        messages.send(payer, "database-error");
                        plugin.getLogger().warning("Payment failed: " + error.getMessage());
                        return;
                    }
                    if (result == SQLiteStorage.PaymentResult.INSUFFICIENT_FUNDS) {
                        messages.send(payer, "insufficient-funds");
                        return;
                    }
                    if (result == SQLiteStorage.PaymentResult.INVALID) {
                        messages.send(payer, "invalid-number");
                        return;
                    }
                    String symbol = plugin.getConfig().getString("currency.symbol", "$" );
                    String formatted = Money.format(amountCents);
                    if (payer.isOnline()) messages.send(payer, "pay-success", "%symbol%", symbol, "%amount%", formatted, "%player%", finalRecipient.getName());
                    if (finalRecipient.isOnline()) messages.send(finalRecipient, "pay-received", "%symbol%", symbol, "%amount%", formatted, "%player%", payer.getName());
                }));
        return true;
    }
}
