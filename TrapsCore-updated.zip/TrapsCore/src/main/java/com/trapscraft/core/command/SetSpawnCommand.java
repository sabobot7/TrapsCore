package com.trapscraft.core.command;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.util.Messages;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class SetSpawnCommand implements CommandExecutor {
    private final TrapsCore plugin;
    private final Messages messages;

    public SetSpawnCommand(TrapsCore plugin) {
        this.plugin = plugin;
        this.messages = plugin.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            messages.send(sender, "players-only");
            return true;
        }
        if (!player.hasPermission("trapscore.admin.setspawn")) {
            messages.send(player, "no-permission");
            return true;
        }
        var location = player.getLocation();
        plugin.getConfig().set("spawn.set", true);
        plugin.getConfig().set("spawn.world", location.getWorld().getName());
        plugin.getConfig().set("spawn.x", location.getX());
        plugin.getConfig().set("spawn.y", location.getY());
        plugin.getConfig().set("spawn.z", location.getZ());
        plugin.getConfig().set("spawn.yaw", location.getYaw());
        plugin.getConfig().set("spawn.pitch", location.getPitch());
        plugin.saveConfig();
        messages.send(player, "spawn-set");
        return true;
    }
}
