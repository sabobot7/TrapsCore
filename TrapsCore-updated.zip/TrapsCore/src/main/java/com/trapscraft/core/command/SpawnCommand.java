package com.trapscraft.core.command;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class SpawnCommand implements CommandExecutor {
    private final TrapsCore plugin;
    private final Messages messages;

    public SpawnCommand(TrapsCore plugin) {
        this.plugin = plugin;
        this.messages = plugin.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            messages.send(sender, "players-only");
            return true;
        }
        if (!plugin.getConfig().getBoolean("spawn.set", false)) {
            messages.send(player, "spawn-not-set");
            return true;
        }
        String worldName = plugin.getConfig().getString("spawn.world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            messages.send(player, "spawn-not-set");
            return true;
        }
        Location location = new Location(world,
                plugin.getConfig().getDouble("spawn.x"),
                plugin.getConfig().getDouble("spawn.y"),
                plugin.getConfig().getDouble("spawn.z"),
                (float) plugin.getConfig().getDouble("spawn.yaw"),
                (float) plugin.getConfig().getDouble("spawn.pitch"));
        player.teleportAsync(location).thenAccept(success -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (success && player.isOnline()) messages.send(player, "teleported-spawn");
        }));
        return true;
    }
}
