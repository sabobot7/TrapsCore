package com.trapscraft.core.delivery;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.storage.SQLiteStorage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Durable, journaled item delivery. Tagged items are locked until SQLite confirms delivery. */
public final class DeliveryService {
    private final TrapsCore plugin;
    private final SQLiteStorage storage;
    private final NamespacedKey deliveryKey;
    private final Set<UUID> processing = ConcurrentHashMap.newKeySet();

    public DeliveryService(TrapsCore plugin, SQLiteStorage storage) {
        this.plugin = plugin;
        this.storage = storage;
        this.deliveryKey = new NamespacedKey(plugin, "delivery_id");
    }

    public void process(Player player) {
        if (!processing.add(player.getUniqueId())) return;
        recoverMarkedItems(player, markerIds(player.getInventory()), 0, () -> loadPending(player));
    }

    private void recoverMarkedItems(Player player, List<String> ids, int index, Runnable continuation) {
        if (!player.isOnline()) {
            processing.remove(player.getUniqueId());
            return;
        }
        if (index >= ids.size()) {
            continuation.run();
            return;
        }
        String id = ids.get(index);
        storage.completeDelivery(id).whenComplete((success, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error != null) {
                plugin.getLogger().warning("Could not reconcile marked delivery " + id + ": " + error.getMessage());
                retry(player);
                return;
            }
            // A marker is only placed after a durable delivery row exists. If the row is absent,
            // clear the orphan marker but retain the player's actual item.
            stripMarker(player.getInventory(), id);
            recoverMarkedItems(player, ids, index + 1, continuation);
        }));
    }

    private void loadPending(Player player) {
        storage.pendingDeliveries(player.getUniqueId()).whenComplete((deliveries, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) {
                        processing.remove(player.getUniqueId());
                        return;
                    }
                    if (error != null) {
                        plugin.getLogger().warning("Could not load pending item deliveries: " + error.getMessage());
                        retry(player);
                        return;
                    }
                    deliverNext(player, deliveries, 0);
                }));
    }

    private void deliverNext(Player player, List<SQLiteStorage.PendingDelivery> deliveries, int index) {
        if (!player.isOnline() || index >= deliveries.size()) {
            processing.remove(player.getUniqueId());
            return;
        }
        SQLiteStorage.PendingDelivery delivery = deliveries.get(index);
        if (hasMarker(player.getInventory(), delivery.id())) {
            finishDelivery(player, deliveries, index, delivery.id());
            return;
        }
        int slot = player.getInventory().firstEmpty();
        if (slot < 0) {
            plugin.messages().send(player, "delivery-inventory-full");
            processing.remove(player.getUniqueId());
            return;
        }
        try {
            ItemStack item = ItemStack.deserializeBytes(delivery.itemBytes());
            if (item == null || item.getType() == Material.AIR || item.getAmount() <= 0) {
                throw new IllegalStateException("Stored delivery item is invalid");
            }
            var meta = item.getItemMeta();
            meta.getPersistentDataContainer().set(deliveryKey, PersistentDataType.STRING, delivery.id());
            item.setItemMeta(meta);
            player.getInventory().setItem(slot, item);
            finishDelivery(player, deliveries, index, delivery.id());
        } catch (Exception exception) {
            plugin.getLogger().severe("Could not deserialize delivery " + delivery.id() + ": " + exception.getMessage());
            plugin.messages().send(player, "delivery-error");
            processing.remove(player.getUniqueId());
        }
    }

    private void finishDelivery(Player player, List<SQLiteStorage.PendingDelivery> deliveries, int index, String id) {
        storage.completeDelivery(id).whenComplete((success, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error != null || !Boolean.TRUE.equals(success)) {
                plugin.getLogger().warning("Delivery remains pending for " + id + (error == null ? "" : ": " + error.getMessage()));
                retry(player);
                return;
            }
            stripMarker(player.getInventory(), id);
            deliverNext(player, deliveries, index + 1);
        }));
    }

    private void retry(Player player) {
        processing.remove(player.getUniqueId());
        if (player.isOnline()) Bukkit.getScheduler().runTaskLater(plugin, () -> process(player), 100L);
    }

    private List<String> markerIds(PlayerInventory inventory) {
        java.util.LinkedHashSet<String> ids = new java.util.LinkedHashSet<>();
        for (ItemStack item : inventory.getContents()) {
            String id = marker(item);
            if (id != null) ids.add(id);
        }
        String offhand = marker(inventory.getItemInOffHand());
        if (offhand != null) ids.add(offhand);
        return new java.util.ArrayList<>(ids);
    }

    public boolean hasLockedItems(Player player) {
        for (ItemStack item : player.getInventory().getContents()) if (isLocked(item)) return true;
        return isLocked(player.getInventory().getItemInOffHand());
    }

    private boolean hasMarker(PlayerInventory inventory, String id) {
        for (ItemStack item : inventory.getContents()) {
            if (id.equals(marker(item))) return true;
        }
        return id.equals(marker(inventory.getItemInOffHand()));
    }

    private void stripMarker(PlayerInventory inventory, String id) {
        ItemStack[] contents = inventory.getContents();
        for (int slot = 0; slot < contents.length; slot++) {
            ItemStack item = contents[slot];
            if (id.equals(marker(item))) {
                var meta = item.getItemMeta();
                meta.getPersistentDataContainer().remove(deliveryKey);
                item.setItemMeta(meta);
                inventory.setItem(slot, item);
            }
        }
        ItemStack offhand = inventory.getItemInOffHand();
        if (id.equals(marker(offhand))) {
            var meta = offhand.getItemMeta();
            meta.getPersistentDataContainer().remove(deliveryKey);
            offhand.setItemMeta(meta);
            inventory.setItemInOffHand(offhand);
        }
    }

    private String marker(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(deliveryKey, PersistentDataType.STRING);
    }

    public boolean isLocked(ItemStack item) {
        return marker(item) != null;
    }

    public void handleJoin(Player player) {
        process(player);
    }
}
