package com.trapscraft.core.economy;

import com.trapscraft.core.storage.SQLiteStorage;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class EconomyService {
    private final SQLiteStorage storage;

    public EconomyService(SQLiteStorage storage) {
        this.storage = storage;
    }

    public CompletableFuture<Double> getBalance(UUID uuid) { return storage.getBalance(uuid); }
    public CompletableFuture<Long> getBalanceCents(UUID uuid) { return storage.getBalanceCents(uuid); }
    public CompletableFuture<SQLiteStorage.PaymentResult> pay(UUID from, UUID to, double amount) { return storage.transfer(from, to, amount); }
    public CompletableFuture<SQLiteStorage.PaymentResult> payCents(UUID from, UUID to, long cents) { return storage.transferCents(from, to, cents); }
    public CompletableFuture<SQLiteStorage.BalanceUpdate> modify(UUID uuid, double amount, String operation) {
        return storage.modifyBalance(uuid, amount, operation);
    }
    public CompletableFuture<SQLiteStorage.BalanceUpdate> modifyCents(UUID uuid, long cents, String operation) {
        return storage.modifyBalanceCents(uuid, cents, operation);
    }
}
