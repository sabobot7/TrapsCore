package com.trapscraft.core.menu;

import com.trapscraft.core.auction.AuctionMenuHolder;
import com.trapscraft.core.auction.AuctionService;
import com.trapscraft.core.delivery.DeliveryService;
import com.trapscraft.core.shop.ShopMenuHolder;
import com.trapscraft.core.shop.ShopService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.ItemStack;

public final class MenuListener implements Listener {
    private final ShopService shop;
    private final AuctionService auctions;
    private final DeliveryService deliveries;

    public MenuListener(ShopService shop, AuctionService auctions, DeliveryService deliveries) {
        this.shop = shop;
        this.auctions = auctions;
        this.deliveries = deliveries;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (auctions.isPendingSeller(player.getUniqueId()) || deliveries.hasLockedItems(player)
                || auctions.hasDraftItems(player) || deliveries.isLocked(event.getCurrentItem())
                || deliveries.isLocked(event.getCursor()) || auctions.isDraftItem(event.getCurrentItem())
                || auctions.isDraftItem(event.getCursor())) {
            event.setCancelled(true);
            return;
        }
        if (event.getView().getTopInventory().getHolder() instanceof ShopMenuHolder holder) {
            event.setCancelled(true);
            if (event.getClickedInventory() == event.getView().getTopInventory()) {
                shop.handleClick(player, holder, event.getRawSlot());
            }
        } else if (event.getView().getTopInventory().getHolder() instanceof AuctionMenuHolder holder) {
            event.setCancelled(true);
            if (event.getClickedInventory() == event.getView().getTopInventory()) {
                auctions.handleClick(player, holder, event.getRawSlot());
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (auctions.isPendingSeller(player.getUniqueId()) || deliveries.hasLockedItems(player)
                || auctions.hasDraftItems(player) || deliveries.isLocked(event.getOldCursor())
                || auctions.isDraftItem(event.getOldCursor())
                || event.getView().getTopInventory().getHolder() instanceof ShopMenuHolder
                || event.getView().getTopInventory().getHolder() instanceof AuctionMenuHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        ItemStack item = event.getItemDrop().getItemStack();
        if (auctions.isPendingSeller(event.getPlayer().getUniqueId()) || deliveries.hasLockedItems(event.getPlayer())
                || auctions.hasDraftItems(event.getPlayer()) || deliveries.isLocked(item) || auctions.isDraftItem(item)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent event) {
        if (auctions.isPendingSeller(event.getPlayer().getUniqueId()) || deliveries.hasLockedItems(event.getPlayer())
                || auctions.hasDraftItems(event.getPlayer())
                || deliveries.isLocked(event.getMainHandItem()) || deliveries.isLocked(event.getOffHandItem())
                || auctions.isDraftItem(event.getMainHandItem()) || auctions.isDraftItem(event.getOffHandItem())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (auctions.isPendingSeller(event.getPlayer().getUniqueId())
                || deliveries.isLocked(event.getItem()) || auctions.isDraftItem(event.getItem())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        if (auctions.isPendingSeller(player.getUniqueId())
                || deliveries.isLocked(player.getInventory().getItemInMainHand())
                || deliveries.isLocked(player.getInventory().getItemInOffHand())
                || auctions.isDraftItem(player.getInventory().getItemInMainHand())
                || auctions.isDraftItem(player.getInventory().getItemInOffHand())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent event) {
        if (deliveries.isLocked(event.getItem()) || auctions.isDraftItem(event.getItem())) event.setCancelled(true);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (auctions.isPendingSeller(player.getUniqueId()) || deliveries.isLocked(hand) || auctions.isDraftItem(hand)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onItemDamage(PlayerItemDamageEvent event) {
        if (deliveries.isLocked(event.getItem()) || auctions.isDraftItem(event.getItem())) event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryMove(InventoryMoveItemEvent event) {
        if (deliveries.isLocked(event.getItem()) || auctions.isDraftItem(event.getItem())) event.setCancelled(true);
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent event) {
        if (deliveries.isLocked(event.getItem().getItemStack()) || auctions.isDraftItem(event.getItem().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        auctions.recoverPrepared(event.getPlayer());
        shop.recoverPending(event.getPlayer());
        deliveries.handleJoin(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        auctions.recoverPrepared(event.getPlayer());
        shop.recoverPending(event.getPlayer());
        deliveries.handleJoin(event.getPlayer());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        auctions.handleDeath(event.getEntity(), event.getDrops());
        event.getDrops().removeIf(deliveries::isLocked);
    }
}
