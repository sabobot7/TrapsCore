package com.trapscraft.core.shop;

import com.trapscraft.core.TrapsCore;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class ShopCommand implements CommandExecutor {
    private final TrapsCore plugin;
    private final ShopService shop;

    public ShopCommand(TrapsCore plugin, ShopService shop) {
        this.plugin = plugin;
        this.shop = shop;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("trapscore.admin.shop")) {
                plugin.messages().send(sender, "no-permission");
                return true;
            }
            shop.reload();
            sender.sendMessage(plugin.messages().color("&aتم تحديث إعدادات المتجر"));
            return true;
        }
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "players-only");
            return true;
        }
        shop.open(player);
        return true;
    }
}
