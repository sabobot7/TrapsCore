package com.trapscraft.core.shop;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

public final class ShopMenuHolder implements InventoryHolder {
    public enum Type { CATEGORIES, ITEMS }
    private final Type type;
    private final String category;
    private final Map<Integer, ShopService.ShopEntry> entries = new HashMap<>();
    private final Map<Integer, String> categories = new HashMap<>();
    private Inventory inventory;

    public ShopMenuHolder(Type type, String category) {
        this.type = type;
        this.category = category;
    }
    public Type type() { return type; }
    public String category() { return category; }
    public Map<Integer, ShopService.ShopEntry> entries() { return entries; }
    public Map<Integer, String> categories() { return categories; }
    public void inventory(Inventory inventory) { this.inventory = inventory; }
    @Override public Inventory getInventory() { return inventory; }
}
