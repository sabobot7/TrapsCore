package com.trapscraft.core.shop;

import com.trapscraft.core.TrapsCore;
import com.trapscraft.core.delivery.DeliveryService;
import com.trapscraft.core.storage.SQLiteStorage;
import com.trapscraft.core.util.Money;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ShopService {
    private static final Set<Material> ALLOWED = EnumSet.of(
            Material.TOTEM_OF_UNDYING, Material.GOLDEN_APPLE, Material.ENCHANTED_GOLDEN_APPLE,
            Material.ENDER_PEARL, Material.CHORUS_FRUIT, Material.ENDER_CHEST, Material.SHULKER_BOX,
            Material.PISTON, Material.STICKY_PISTON, Material.OBSERVER, Material.DISPENSER,
            Material.DROPPER, Material.REDSTONE, Material.REPEATER, Material.COMPARATOR,
            Material.TRIPWIRE_HOOK, Material.STRING, Material.STONE_PRESSURE_PLATE,
            Material.SCULK_SENSOR, Material.TRAPPED_CHEST, Material.LEVER, Material.STONE_BUTTON,
            Material.COBWEB, Material.SLIME_BLOCK, Material.HONEY_BLOCK, Material.END_ROD,
            Material.WATER_BUCKET
    );

    private final TrapsCore plugin;
    private final SQLiteStorage storage;
    private final DeliveryService deliveries;
    private final Set<UUID> purchasing = ConcurrentHashMap.newKeySet();
    private final Map<UUID, PendingShopPurchase> retryPurchases = new ConcurrentHashMap<>();
    private YamlConfiguration config;

    public ShopService(TrapsCore plugin, SQLiteStorage storage, DeliveryService deliveries) {
        this.plugin = plugin;
        this.storage = storage;
        this.deliveries = deliveries;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "shop.yml");
        if (!file.exists()) plugin.saveResource("shop.yml", false);
        this.config = YamlConfiguration.loadConfiguration(file);
    }

    public void open(Player player) {
        ConfigurationSection categories = config.getConfigurationSection("categories");
        if (categories == null) {
            player.sendMessage(color("&cShop configuration has no categories."));
            return;
        }
        ShopMenuHolder holder = new ShopMenuHolder(ShopMenuHolder.Type.CATEGORIES, null);
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&3Traps Craft &8| &bShop"));
        int[] slots = {10, 12, 14, 16, 22};
        int index = 0;
        for (String key : categories.getKeys(false)) {
            if (index >= slots.length) break;
            ConfigurationSection section = categories.getConfigurationSection(key);
            if (section == null) continue;
            Material icon = Material.matchMaterial(section.getString("icon", "CHEST"));
            if (icon == null || !ALLOWED.contains(icon)) icon = Material.CHEST;
            ItemStack item = new ItemStack(icon);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(color(section.getString("name", key)));
            meta.setLore(List.of(color("&7اضغط لعرض المواد")));
            item.setItemMeta(meta);
            inventory.setItem(slots[index], item);
            holder.categories().put(slots[index], key);
            index++;
        }
        holder.inventory(inventory);
        player.openInventory(inventory);
    }

    private void openCategory(Player player, String category) {
        ConfigurationSection section = config.getConfigurationSection("categories." + category + ".items");
        if (section == null) {
            player.sendMessage(color("&cThis shop category is empty."));
            return;
        }
        ShopMenuHolder holder = new ShopMenuHolder(ShopMenuHolder.Type.ITEMS, category);
        Inventory inventory = Bukkit.createInventory(holder, 54,
                color("&3Traps Craft &8| &b" + config.getString("categories." + category + ".name", category)));
        int slot = 0;
        for (String materialName : section.getKeys(false)) {
            if (slot >= 45) break;
            Material material = Material.matchMaterial(materialName);
            if (material == null || !ALLOWED.contains(material)) continue;
            ConfigurationSection itemSection = section.getConfigurationSection(materialName);
            if (itemSection == null || !itemSection.getBoolean("enabled", true)) continue;
            long price;
            try { price = Money.parseCents(String.valueOf(itemSection.get("price", "1.00"))); }
            catch (IllegalArgumentException exception) { continue; }
            int amount = itemSection.getInt("amount", 1);
            if (amount < 1 || amount > material.getMaxStackSize()) continue;
            ShopEntry entry = new ShopEntry(material, price, amount,
                    itemSection.getString("display-name", "&f" + pretty(material.name())));
            ItemStack display = new ItemStack(material, amount);
            ItemMeta meta = display.getItemMeta();
            meta.setDisplayName(color(entry.displayName()));
            meta.setLore(List.of(color("&7السعر: &a" + plugin.getConfig().getString("currency.symbol", "$" ) + Money.format(price)),
                    color("&eاضغط للشراء")));
            display.setItemMeta(meta);
            inventory.setItem(slot, display);
            holder.entries().put(slot, entry);
            slot++;
        }
        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.setDisplayName(color("&cرجوع"));
        back.setItemMeta(backMeta);
        inventory.setItem(49, back);
        holder.inventory(inventory);
        player.openInventory(inventory);
    }

    public void handleClick(Player player, ShopMenuHolder holder, int rawSlot) {
        if (rawSlot < 0 || rawSlot >= holder.getInventory().getSize()) return;
        if (holder.type() == ShopMenuHolder.Type.CATEGORIES) {
            String category = holder.categories().get(rawSlot);
            if (category != null) openCategory(player, category);
            return;
        }
        if (rawSlot == 49) {
            open(player);
            return;
        }
        ShopEntry entry = holder.entries().get(rawSlot);
        if (entry == null || !purchasing.add(player.getUniqueId())) return;
        PendingShopPurchase pending = retryPurchases.computeIfAbsent(player.getUniqueId(), ignored -> {
            ItemStack item = new ItemStack(entry.material(), entry.amount());
            return new PendingShopPurchase(UUID.randomUUID().toString(), entry.priceCents(), item.serializeAsBytes(),
                    entry.material().name(), entry.amount());
        });
        if (pending.material().equals(entry.material().name())) {
            // same requested item; a previous uncertain database result is safely retried with its original id
        } else {
            player.sendMessage(color("&eيتم استكمال عملية الشراء السابقة أولاً"));
        }
        storage.purchaseShop(player.getUniqueId(), pending.priceCents(), pending.id(), pending.itemBytes(),
                pending.material(), pending.amount()).whenComplete((result, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    purchasing.remove(player.getUniqueId());
                    if (error != null) {
                        plugin.getLogger().warning("Shop purchase failed: " + error.getMessage());
                        if (player.isOnline()) plugin.messages().send(player, "database-error");
                        return; // keep the same request and id for a safe retry
                    }
                    retryPurchases.remove(player.getUniqueId(), pending);
                    if (!player.isOnline()) return;
                    if (result == SQLiteStorage.PurchaseResult.INSUFFICIENT_FUNDS) {
                        plugin.messages().send(player, "insufficient-funds");
                        return;
                    }
                    player.sendMessage(color("&aتم الشراء بنجاح، جاري تسليم الغرض"));
                    deliveries.process(player);
                }));
    }

    public void recoverPending(Player player) {
        PendingShopPurchase pending = retryPurchases.get(player.getUniqueId());
        if (pending == null) return;
        storage.deliveryExists(pending.id(), player.getUniqueId()).thenAccept(exists -> {
            if (exists) retryPurchases.remove(player.getUniqueId(), pending);
        });
    }

    public boolean isAllowed(Material material) { return ALLOWED.contains(material); }
    private String pretty(String input) { return input.toLowerCase(Locale.ROOT).replace('_', ' '); }
    private String color(String input) { return ChatColor.translateAlternateColorCodes('&', input); }

    public record ShopEntry(Material material, long priceCents, int amount, String displayName) { }
    private record PendingShopPurchase(String id, long priceCents, byte[] itemBytes, String material, int amount) { }
}
