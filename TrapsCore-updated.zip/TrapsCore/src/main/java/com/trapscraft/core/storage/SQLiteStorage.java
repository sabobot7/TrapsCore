package com.trapscraft.core.storage;

import com.trapscraft.core.util.Money;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** SQLite-backed economy, auction escrow and durable item-delivery journal. */
public final class SQLiteStorage {
    private static final long MAX_CENTS = 9_000_000_000_000_000L;
    private final String jdbcUrl;
    private final long startingBalanceCents;
    private final ExecutorService databaseExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "TrapsCore-SQLite");
        thread.setDaemon(true);
        return thread;
    });

    public SQLiteStorage(JavaPlugin plugin) {
        File database = new File(plugin.getDataFolder(), "data.db");
        this.jdbcUrl = "jdbc:sqlite:" + database.getAbsolutePath();
        this.startingBalanceCents = Money.fromDouble(plugin.getConfig().getDouble("currency.starting-balance", 1000.0));
    }

    public void initialize(JavaPlugin plugin) throws SQLException {
        if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
            throw new SQLException("Could not create plugin data directory.");
        }
        try (Connection connection = connect(); Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA journal_mode = WAL");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS balances (uuid TEXT PRIMARY KEY, balance REAL NOT NULL CHECK(balance >= 0))");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, from_uuid TEXT, to_uuid TEXT, amount REAL NOT NULL, type TEXT NOT NULL, created_at INTEGER NOT NULL)");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS wallets (uuid TEXT PRIMARY KEY, cents INTEGER NOT NULL CHECK(cents >= 0))");
            statement.executeUpdate("INSERT OR IGNORE INTO wallets(uuid, cents) SELECT uuid, CAST(ROUND(balance * 100) AS INTEGER) FROM balances");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS economy_ledger (operation_id TEXT PRIMARY KEY, from_uuid TEXT, to_uuid TEXT, amount_cents INTEGER NOT NULL, type TEXT NOT NULL, created_at INTEGER NOT NULL)");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS deliveries (id TEXT PRIMARY KEY, player_uuid TEXT NOT NULL, item_blob BLOB NOT NULL, status TEXT NOT NULL, source_type TEXT NOT NULL, source_id TEXT, created_at INTEGER NOT NULL)");
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_deliveries_player_status ON deliveries(player_uuid, status)");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS auction_listings (id TEXT PRIMARY KEY, seller_uuid TEXT NOT NULL, seller_name TEXT NOT NULL, item_blob BLOB NOT NULL, material TEXT NOT NULL, amount INTEGER NOT NULL, price_cents INTEGER NOT NULL CHECK(price_cents > 0), status TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL)");
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_auction_status_expiry ON auction_listings(status, expires_at)");
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_auction_seller ON auction_listings(seller_uuid, status)");
        }
    }

    private Connection connect() throws SQLException {
        Connection connection = DriverManager.getConnection(jdbcUrl);
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA busy_timeout = 10000");
            statement.execute("PRAGMA foreign_keys = ON");
        }
        return connection;
    }

    private <T> CompletableFuture<T> async(SqlWork<T> work) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection connection = connect()) {
                return work.run(connection);
            } catch (Exception exception) {
                throw new RuntimeException(exception);
            }
        }, databaseExecutor);
    }

    public CompletableFuture<Double> getBalance(UUID uuid) {
        return getBalanceCents(uuid).thenApply(Money::asDouble);
    }

    public CompletableFuture<Long> getBalanceCents(UUID uuid) {
        return async(connection -> {
            ensureWallet(connection, uuid);
            return readCents(connection, uuid);
        });
    }

    public CompletableFuture<PaymentResult> transfer(UUID from, UUID to, double amount) {
        final long cents;
        try { cents = Money.fromDouble(amount); }
        catch (IllegalArgumentException exception) { return CompletableFuture.failedFuture(exception); }
        return transferCents(from, to, cents);
    }

    public CompletableFuture<PaymentResult> transferCents(UUID from, UUID to, long cents) {
        if (cents <= 0 || cents > MAX_CENTS || from.equals(to)) return CompletableFuture.completedFuture(PaymentResult.INVALID);
        return async(connection -> inTransaction(connection, () -> {
            ensureWallet(connection, from);
            ensureWallet(connection, to);
            if (!debit(connection, from, cents)) return PaymentResult.INSUFFICIENT_FUNDS;
            credit(connection, to, cents);
            logEconomy(connection, UUID.randomUUID().toString(), from.toString(), to.toString(), cents, "PAY");
            return PaymentResult.SUCCESS;
        }));
    }

    public CompletableFuture<BalanceUpdate> modifyBalance(UUID uuid, double amount, String operation) {
        final long cents;
        try { cents = Money.fromDouble(amount); }
        catch (IllegalArgumentException exception) { return CompletableFuture.failedFuture(exception); }
        return modifyBalanceCents(uuid, cents, operation);
    }

    public CompletableFuture<BalanceUpdate> modifyBalanceCents(UUID uuid, long cents, String operation) {
        if (cents < 0 || cents > MAX_CENTS) return CompletableFuture.failedFuture(new IllegalArgumentException("Invalid cents"));
        return async(connection -> inTransaction(connection, () -> {
            ensureWallet(connection, uuid);
            long current = readCents(connection, uuid);
            long updated = switch (operation.toLowerCase()) {
                case "give" -> safeAdd(current, cents);
                case "take" -> current >= cents ? current - cents : -1;
                case "set" -> cents;
                default -> throw new IllegalArgumentException("Unknown economy operation: " + operation);
            };
            if (updated < 0 || updated > MAX_CENTS) return new BalanceUpdate(false, current);
            try (PreparedStatement statement = connection.prepareStatement("UPDATE wallets SET cents = ? WHERE uuid = ?")) {
                statement.setLong(1, updated);
                statement.setString(2, uuid.toString());
                statement.executeUpdate();
            }
            logEconomy(connection, UUID.randomUUID().toString(), null, uuid.toString(), cents, "ADMIN_" + operation.toUpperCase());
            return new BalanceUpdate(true, updated);
        }));
    }

    public CompletableFuture<PurchaseResult> purchaseShop(UUID buyer, long priceCents, String deliveryId,
                                                            byte[] itemBytes, String material, int amount) {
        if (priceCents <= 0 || amount <= 0 || itemBytes == null || itemBytes.length == 0) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Invalid shop purchase"));
        }
        return async(connection -> inTransaction(connection, () -> {
            String existingOwner = deliveryOwner(connection, deliveryId);
            if (existingOwner != null) {
                if (!existingOwner.equals(buyer.toString())) throw new SQLException("Delivery id belongs to another player");
                return PurchaseResult.SUCCESS;
            }
            ensureWallet(connection, buyer);
            if (!debit(connection, buyer, priceCents)) return PurchaseResult.INSUFFICIENT_FUNDS;
            insertDelivery(connection, deliveryId, buyer, itemBytes, "SHOP", material);
            logEconomy(connection, deliveryId, buyer.toString(), null, priceCents, "SHOP_BUY");
            return PurchaseResult.SUCCESS;
        }));
    }

    public CompletableFuture<Boolean> prepareAuction(String id, UUID seller, String sellerName, byte[] itemBytes,
                                                      String material, int amount, long priceCents, long expiresAt) {
        return async(connection -> inTransaction(connection, () -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO auction_listings(id,seller_uuid,seller_name,item_blob,material,amount,price_cents,status,created_at,expires_at) VALUES(?,?,?,?,?,?,?,'PREPARED',?,?)")) {
                statement.setString(1, id);
                statement.setString(2, seller.toString());
                statement.setString(3, sellerName);
                statement.setBytes(4, itemBytes);
                statement.setString(5, material);
                statement.setInt(6, amount);
                statement.setLong(7, priceCents);
                statement.setLong(8, System.currentTimeMillis());
                statement.setLong(9, expiresAt);
                statement.executeUpdate();
            }
            return true;
        }));
    }

    public CompletableFuture<Boolean> activateAuction(String id) {
        return async(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE auction_listings SET status='ACTIVE' WHERE id=? AND status='PREPARED'")) {
                statement.setString(1, id);
                return statement.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Void> cancelAuctionDraft(String id) {
        return async(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE auction_listings SET status='CANCELLED' WHERE id=? AND status='PREPARED'")) {
                statement.setString(1, id);
                statement.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<List<String>> preparedAuctions(UUID seller) {
        return async(connection -> {
            List<String> ids = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT id FROM auction_listings WHERE seller_uuid=? AND status='PREPARED'")) {
                statement.setString(1, seller.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) ids.add(result.getString("id"));
                }
            }
            return ids;
        });
    }

    public CompletableFuture<List<AuctionListing>> activeAuctions(int page, int pageSize) {
        int safePage = Math.max(0, page);
        int safeSize = Math.max(1, Math.min(45, pageSize));
        return async(connection -> {
            List<AuctionListing> listings = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT id,seller_uuid,seller_name,item_blob,material,amount,price_cents,created_at,expires_at FROM auction_listings WHERE status='ACTIVE' AND expires_at>? ORDER BY created_at DESC LIMIT ? OFFSET ?")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setInt(2, safeSize);
                statement.setInt(3, safePage * safeSize);
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        listings.add(new AuctionListing(result.getString("id"), UUID.fromString(result.getString("seller_uuid")),
                                result.getString("seller_name"), result.getBytes("item_blob"), result.getString("material"),
                                result.getInt("amount"), result.getLong("price_cents"), result.getLong("created_at"),
                                result.getLong("expires_at")));
                    }
                }
            }
            return listings;
        });
    }

    public CompletableFuture<AuctionBuyResult> buyAuction(UUID buyer, String listingId, String deliveryId) {
        return async(connection -> inTransaction(connection, () -> {
            String sellerText;
            String sellerName;
            byte[] itemBytes;
            long price;
            long expires;
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT seller_uuid,seller_name,item_blob,price_cents,expires_at,status FROM auction_listings WHERE id=?")) {
                statement.setString(1, listingId);
                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) return AuctionBuyResult.NOT_FOUND;
                    if (!"ACTIVE".equals(result.getString("status"))) return AuctionBuyResult.UNAVAILABLE;
                    sellerText = result.getString("seller_uuid");
                    sellerName = result.getString("seller_name");
                    itemBytes = result.getBytes("item_blob");
                    price = result.getLong("price_cents");
                    expires = result.getLong("expires_at");
                }
            }
            if (expires <= System.currentTimeMillis()) {
                try (PreparedStatement statement = connection.prepareStatement(
                        "UPDATE auction_listings SET status='RETURN_PENDING' WHERE id=? AND status='ACTIVE'")) {
                    statement.setString(1, listingId);
                    statement.executeUpdate();
                }
                return AuctionBuyResult.EXPIRED;
            }
            UUID seller = UUID.fromString(sellerText);
            if (seller.equals(buyer)) return AuctionBuyResult.OWN_LISTING;
            ensureWallet(connection, buyer);
            ensureWallet(connection, seller);
            if (!debit(connection, buyer, price)) return AuctionBuyResult.INSUFFICIENT_FUNDS;
            credit(connection, seller, price);
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE auction_listings SET status='SOLD' WHERE id=? AND status='ACTIVE'")) {
                statement.setString(1, listingId);
                if (statement.executeUpdate() != 1) throw new SQLException("Auction state changed during purchase");
            }
            insertDelivery(connection, deliveryId, buyer, itemBytes, "AUCTION_SALE", listingId);
            logEconomy(connection, deliveryId, buyer.toString(), seller.toString(), price, "AH_BUY");
            return new AuctionBuyResult(AuctionBuyStatus.SUCCESS, price, sellerName);
        }));
    }

    public CompletableFuture<AuctionCancelResult> cancelAuction(UUID seller, String idPrefix) {
        return async(connection -> inTransaction(connection, () -> {
            String id = null;
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT id FROM auction_listings WHERE id LIKE ? AND seller_uuid=? AND status='ACTIVE'")) {
                statement.setString(1, idPrefix + "%");
                statement.setString(2, seller.toString());
                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) return AuctionCancelResult.NOT_FOUND;
                    id = result.getString("id");
                    if (result.next()) return AuctionCancelResult.AMBIGUOUS;
                }
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE auction_listings SET status='RETURN_PENDING' WHERE id=? AND seller_uuid=? AND status='ACTIVE'")) {
                statement.setString(1, id);
                statement.setString(2, seller.toString());
                return statement.executeUpdate() == 1 ? AuctionCancelResult.SUCCESS : AuctionCancelResult.NOT_FOUND;
            }
        }));
    }

    public CompletableFuture<Integer> expireAuctions() {
        return async(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE auction_listings SET status='RETURN_PENDING' WHERE status='ACTIVE' AND expires_at<=?")) {
                statement.setLong(1, System.currentTimeMillis());
                return statement.executeUpdate();
            }
        });
    }

    public CompletableFuture<Integer> queueAuctionReturns() {
        return async(connection -> inTransaction(connection, () -> {
            List<ReturnRow> rows = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT id,seller_uuid,item_blob FROM auction_listings WHERE status='RETURN_PENDING'")) {
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) rows.add(new ReturnRow(result.getString("id"),
                            UUID.fromString(result.getString("seller_uuid")), result.getBytes("item_blob")));
                }
            }
            for (ReturnRow row : rows) {
                insertDelivery(connection, "auction-return-" + row.id(), row.seller(), row.itemBytes(), "AUCTION_RETURN", row.id());
                try (PreparedStatement statement = connection.prepareStatement(
                        "UPDATE auction_listings SET status='RETURN_QUEUED' WHERE id=? AND status='RETURN_PENDING'")) {
                    statement.setString(1, row.id());
                    statement.executeUpdate();
                }
            }
            return rows.size();
        }));
    }

    public CompletableFuture<Boolean> deliveryExists(String deliveryId, UUID player) {
        return async(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT 1 FROM deliveries WHERE id=? AND player_uuid=?")) {
                statement.setString(1, deliveryId);
                statement.setString(2, player.toString());
                try (ResultSet result = statement.executeQuery()) { return result.next(); }
            }
        });
    }

    public CompletableFuture<List<PendingDelivery>> pendingDeliveries(UUID player) {
        return async(connection -> {
            List<PendingDelivery> deliveries = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT id,item_blob,source_type,source_id FROM deliveries WHERE player_uuid=? AND status='PENDING' ORDER BY created_at")) {
                statement.setString(1, player.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) deliveries.add(new PendingDelivery(result.getString("id"),
                            result.getBytes("item_blob"), result.getString("source_type"), result.getString("source_id")));
                }
            }
            return deliveries;
        });
    }

    public CompletableFuture<Boolean> completeDelivery(String deliveryId) {
        return async(connection -> inTransaction(connection, () -> {
            String sourceType = null;
            String sourceId = null;
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT source_type,source_id,status FROM deliveries WHERE id=?")) {
                statement.setString(1, deliveryId);
                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) return false;
                    if (!"PENDING".equals(result.getString("status"))) return true;
                    sourceType = result.getString("source_type");
                    sourceId = result.getString("source_id");
                }
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE deliveries SET status='DELIVERED' WHERE id=? AND status='PENDING'")) {
                statement.setString(1, deliveryId);
                statement.executeUpdate();
            }
            if ("AUCTION_RETURN".equals(sourceType) && sourceId != null) {
                try (PreparedStatement statement = connection.prepareStatement(
                        "UPDATE auction_listings SET status='RETURNED' WHERE id=? AND status='RETURN_QUEUED'")) {
                    statement.setString(1, sourceId);
                    statement.executeUpdate();
                }
            }
            return true;
        }));
    }

    private void ensureWallet(Connection connection, UUID uuid) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT OR IGNORE INTO wallets(uuid,cents) VALUES(?,?)")) {
            statement.setString(1, uuid.toString());
            statement.setLong(2, startingBalanceCents);
            statement.executeUpdate();
        }
    }

    private long readCents(Connection connection, UUID uuid) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT cents FROM wallets WHERE uuid=?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) throw new SQLException("Missing wallet for " + uuid);
                return result.getLong(1);
            }
        }
    }

    private boolean debit(Connection connection, UUID uuid, long cents) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "UPDATE wallets SET cents=cents-? WHERE uuid=? AND cents>=?")) {
            statement.setLong(1, cents);
            statement.setString(2, uuid.toString());
            statement.setLong(3, cents);
            return statement.executeUpdate() == 1;
        }
    }

    private void credit(Connection connection, UUID uuid, long cents) throws SQLException {
        long current = readCents(connection, uuid);
        long updated = safeAdd(current, cents);
        if (updated < 0 || updated > MAX_CENTS) throw new SQLException("Wallet balance limit exceeded");
        try (PreparedStatement statement = connection.prepareStatement("UPDATE wallets SET cents=? WHERE uuid=?")) {
            statement.setLong(1, updated);
            statement.setString(2, uuid.toString());
            statement.executeUpdate();
        }
    }

    private long safeAdd(long a, long b) {
        if (b > 0 && a > MAX_CENTS - b) return -1;
        return a + b;
    }

    private String deliveryOwner(Connection connection, String id) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT player_uuid FROM deliveries WHERE id=?")) {
            statement.setString(1, id);
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? result.getString(1) : null;
            }
        }
    }

    private void insertDelivery(Connection connection, String id, UUID player, byte[] itemBytes,
                                String sourceType, String sourceId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO deliveries(id,player_uuid,item_blob,status,source_type,source_id,created_at) VALUES(?,?,?,'PENDING',?,?,?)")) {
            statement.setString(1, id);
            statement.setString(2, player.toString());
            statement.setBytes(3, itemBytes);
            statement.setString(4, sourceType);
            statement.setString(5, sourceId);
            statement.setLong(6, System.currentTimeMillis());
            statement.executeUpdate();
        }
    }

    private void logEconomy(Connection connection, String operationId, String from, String to,
                            long cents, String type) throws SQLException {
        long now = System.currentTimeMillis();
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO economy_ledger(operation_id,from_uuid,to_uuid,amount_cents,type,created_at) VALUES(?,?,?,?,?,?)")) {
            statement.setString(1, operationId);
            statement.setString(2, from);
            statement.setString(3, to);
            statement.setLong(4, cents);
            statement.setString(5, type);
            statement.setLong(6, now);
            statement.executeUpdate();
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO transactions(from_uuid,to_uuid,amount,type,created_at) VALUES(?,?,?,?,?)")) {
            statement.setString(1, from);
            statement.setString(2, to);
            statement.setDouble(3, Money.asDouble(cents));
            statement.setString(4, type);
            statement.setLong(5, now);
            statement.executeUpdate();
        }
    }

    private <T> T inTransaction(Connection connection, TransactionWork<T> work) throws Exception {
        connection.setAutoCommit(false);
        try {
            T result = work.run();
            connection.commit();
            return result;
        } catch (Exception exception) {
            connection.rollback();
            throw exception;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    public void close() {
        databaseExecutor.shutdown();
        try {
            if (!databaseExecutor.awaitTermination(3, TimeUnit.SECONDS)) databaseExecutor.shutdownNow();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            databaseExecutor.shutdownNow();
        }
    }

    @FunctionalInterface
    private interface SqlWork<T> { T run(Connection connection) throws Exception; }
    @FunctionalInterface
    private interface TransactionWork<T> { T run() throws Exception; }

    private record ReturnRow(String id, UUID seller, byte[] itemBytes) { }
    public record BalanceUpdate(boolean success, long balanceCents) {
        public double balance() { return Money.asDouble(balanceCents); }
    }
    public enum PaymentResult { SUCCESS, INSUFFICIENT_FUNDS, INVALID }
    public enum PurchaseResult { SUCCESS, INSUFFICIENT_FUNDS }
    public enum AuctionBuyStatus { SUCCESS, INSUFFICIENT_FUNDS, NOT_FOUND, UNAVAILABLE, OWN_LISTING, EXPIRED }
    public record AuctionBuyResult(AuctionBuyStatus status, long priceCents, String sellerName) {
        public static final AuctionBuyResult NOT_FOUND = new AuctionBuyResult(AuctionBuyStatus.NOT_FOUND, 0, "");
        public static final AuctionBuyResult UNAVAILABLE = new AuctionBuyResult(AuctionBuyStatus.UNAVAILABLE, 0, "");
        public static final AuctionBuyResult INSUFFICIENT_FUNDS = new AuctionBuyResult(AuctionBuyStatus.INSUFFICIENT_FUNDS, 0, "");
        public static final AuctionBuyResult OWN_LISTING = new AuctionBuyResult(AuctionBuyStatus.OWN_LISTING, 0, "");
        public static final AuctionBuyResult EXPIRED = new AuctionBuyResult(AuctionBuyStatus.EXPIRED, 0, "");
    }
    public enum AuctionCancelResult { SUCCESS, NOT_FOUND, AMBIGUOUS }
    public record AuctionListing(String id, UUID seller, String sellerName, byte[] itemBytes, String material,
                                 int amount, long priceCents, long createdAt, long expiresAt) { }
    public record PendingDelivery(String id, byte[] itemBytes, String sourceType, String sourceId) { }
}
