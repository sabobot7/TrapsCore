package com.trapscraft.core.util;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class Messages {
    private final JavaPlugin plugin;

    public Messages(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public String raw(String key) {
        String prefix = plugin.getConfig().getString("messages.prefix", "&8[&4TrapsCore&8] &7");
        String message = plugin.getConfig().getString("messages." + key, "&cMissing message: " + key);
        return color(prefix + message);
    }

    public void send(CommandSender sender, String key) {
        sender.sendMessage(raw(key));
    }

    public void send(CommandSender sender, String key, String... replacements) {
        String message = raw(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            message = message.replace(replacements[i], replacements[i + 1]);
        }
        sender.sendMessage(message);
    }

    public String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
