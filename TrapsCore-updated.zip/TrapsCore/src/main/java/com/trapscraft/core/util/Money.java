package com.trapscraft.core.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Exact, two-decimal currency conversion used at every command/storage boundary. */
public final class Money {
    private static final long MAX_CENTS = 9_000_000_000_000_000L;
    private Money() { }

    public static long parseCents(String input) {
        long cents = parseNonNegativeCents(input);
        if (cents == 0) throw new IllegalArgumentException("amount must be positive");
        return cents;
    }

    public static long parseNonNegativeCents(String input) {
        if (input == null || input.isBlank()) throw new IllegalArgumentException("empty amount");
        try {
            BigDecimal value = new BigDecimal(input.trim());
            if (value.scale() > 2 || value.signum() < 0) {
                throw new IllegalArgumentException("amount must be non-negative with at most 2 decimals");
            }
            long cents = value.movePointRight(2).setScale(0, RoundingMode.UNNECESSARY).longValueExact();
            if (cents < 0 || cents > MAX_CENTS) throw new IllegalArgumentException("amount out of range");
            return cents;
        } catch (NumberFormatException | ArithmeticException exception) {
            throw new IllegalArgumentException("invalid amount", exception);
        }
    }

    public static long fromDouble(double amount) {
        if (!Double.isFinite(amount) || amount < 0) throw new IllegalArgumentException("invalid amount");
        try {
            long cents = BigDecimal.valueOf(amount).setScale(2, RoundingMode.HALF_UP)
                    .movePointRight(2).longValueExact();
            if (cents > MAX_CENTS) throw new IllegalArgumentException("amount out of range");
            return cents;
        } catch (ArithmeticException exception) {
            throw new IllegalArgumentException("amount out of range", exception);
        }
    }

    public static String format(long cents) {
        return BigDecimal.valueOf(cents, 2).setScale(2, RoundingMode.UNNECESSARY).toPlainString();
    }

    public static double asDouble(long cents) { return cents / 100.0; }
}
