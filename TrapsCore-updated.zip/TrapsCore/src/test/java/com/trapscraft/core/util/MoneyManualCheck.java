package com.trapscraft.core.util;

public final class MoneyManualCheck {
    public static void main(String[] args) {
        check(Money.parseCents("12") == 1200, "integer amount");
        check(Money.parseCents("12.3") == 1230, "one decimal amount");
        check(Money.parseCents("12.34") == 1234, "two decimal amount");
        check("1234.56".equals(Money.format(123456)), "stable formatting");
        check(Money.fromDouble(12.34) == 1234, "double conversion");
        check(Money.parseNonNegativeCents("0") == 0, "zero for admin set/take");
        check("90000000000000.00".equals(Money.format(9_000_000_000_000_000L)), "large exact formatting");
        reject("0");
        reject("-1");
        reject("1.001");
        reject("NaN");
        reject("Infinity");
        reject("90000000000000.01");
        System.out.println("MoneyManualCheck: 13 checks passed");
    }

    private static void reject(String input) {
        try {
            Money.parseCents(input);
            throw new AssertionError("Expected rejection for: " + input);
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
}
