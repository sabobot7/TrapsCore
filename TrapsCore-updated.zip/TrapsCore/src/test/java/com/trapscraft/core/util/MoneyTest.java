package com.trapscraft.core.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class MoneyTest {
    @Test
    void parsesExactCents() {
        assertEquals(1200, Money.parseCents("12"));
        assertEquals(1230, Money.parseCents("12.3"));
        assertEquals(1234, Money.parseCents("12.34"));
        assertEquals("1234.56", Money.format(123456));
        assertEquals("90000000000000.00", Money.format(9_000_000_000_000_000L));
        assertEquals(0, Money.parseNonNegativeCents("0"));
    }

    @Test
    void rejectsInvalidOrOverPreciseAmounts() {
        assertThrows(IllegalArgumentException.class, () -> Money.parseCents("0"));
        assertThrows(IllegalArgumentException.class, () -> Money.parseCents("-1"));
        assertThrows(IllegalArgumentException.class, () -> Money.parseCents("1.001"));
        assertThrows(IllegalArgumentException.class, () -> Money.parseCents("NaN"));
        assertThrows(IllegalArgumentException.class, () -> Money.parseCents("Infinity"));
    }
}
